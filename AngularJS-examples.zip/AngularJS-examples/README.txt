1. Install express by typing in the command: npm install express
2. Run the server by typing: node server.js
3. Execute the examples by either double clicking the .html file or going to a URL pointing to it, such as: http://localhost:3000/public/ModuleControllerRoutesExample.html#/
4. Review the code of the app accessible through: http://localhost:3000/public/CustomerManagementApp.html#/customers
